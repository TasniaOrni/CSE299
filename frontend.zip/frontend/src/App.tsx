import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import CalendarView from './components/CalendarView';
import SettingsPage from './components/SettingsPage';
import Navigation from './components/Navigation';

export type UserRole = 'student' | 'ta' | 'faculty';
export type CurrentView = 'login' | 'dashboard' | 'calendar' | 'settings';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

function App() {
  const [currentView, setCurrentView] = useState<CurrentView>('login');
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentView('dashboard');
  };

  const handleLogout = async () => {
    try {
      await fetch("http://localhost:8000/logout", {
        method: "GET",
        credentials: "include",
      });
    } catch {
      // ignore network errors for logout
    } finally {
      setUser(null);
      setCurrentView('login');
    }
  };


  const renderCurrentView = () => {
    switch (currentView) {
      case 'login':
        return <LoginPage onLogin={handleLogin} />;
      case 'dashboard':
        return <Dashboard user={user!} />;
      case 'calendar':
        return <CalendarView user={user!} />;
      case 'settings':
        return <SettingsPage user={user!} />;
      case 'settings':
        return <SettingsPage user={user!} />;
      default:
        return <LoginPage onLogin={handleLogin} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {user && currentView !== 'login' && (
        <Navigation
          user={user}
          currentView={currentView}
          onNavigate={setCurrentView}
          onLogout={handleLogout}
        />
      )}
      {renderCurrentView()}
    </div>
  );
}

export default App;