import React, { useEffect, useMemo, useState } from 'react';
import { User } from '../App';
import {
  ChevronLeft, ChevronRight, Plus, RefreshCw,
} from 'lucide-react';
import AddEventModal from './AddEventModal';

interface CalendarViewProps { user: User; }

interface CalendarEvent {
  id: string;
  title: string;
  start: string;      // ISO
  end?: string;       // ISO
  isAllDay?: boolean;
}

const CalendarView: React.FC<CalendarViewProps> = ({ user }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [viewType, setViewType] = useState<'month' | 'week'>('month');
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [syncEnabled, setSyncEnabled] = useState(true);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);

  // Helpers ---------------------------------------------------------

  const monthRange = (date: Date) => {
    const first = new Date(Date.UTC(date.getFullYear(), date.getMonth(), 1, 0, 0, 0));
    const last = new Date(Date.UTC(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59));
    return {
      timeMin: first.toISOString(),
      timeMax: last.toISOString(),
    };
  };
  const eventColors: Record<string, string> = {
    assignment: 'bg-blue-600 hover:bg-blue-700',
    class: 'bg-yellow-600 hover:bg-yellow-700',
    exam: 'bg-red-600 hover:bg-red-700',
    project: 'bg-emerald-600 hover:bg-emerald-700',
    'office-hours': 'bg-purple-600 hover:bg-purple-700',
    reminder: 'bg-gray-600 hover:bg-gray-700',
    default: 'bg-indigo-600 hover:bg-indigo-700', // fallback
  };
  const ymd = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  const parseEventLocalDate = (isoOrDateOnly: string) => {
    // Google may send "YYYY-MM-DD" for all-day or full ISO
    if (isoOrDateOnly.length === 10) {
      const [y, m, d] = isoOrDateOnly.split('-').map(Number);
      return new Date(y, (m - 1), d); // local midnight
    }
    return new Date(isoOrDateOnly); // browser will interpret/offset
  };
  function detectType(title: string): string {
    const lower = title.toLowerCase();
    if (lower.includes('assignment')) return 'assignment';
    if (lower.includes('exam') || lower.includes('midterm') || lower.includes('final')) return 'exam';
    if (lower.includes('project')) return 'project';
    if (lower.includes('office')) return 'office-hours';
    if (lower.includes('reminder')) return 'reminder';
    return 'default';
  }
  // Fetch -----------------------------------------------------------

  const loadEvents = async (forMonth: Date) => {
    setLoading(true);
    try {
      const { timeMin, timeMax } = monthRange(forMonth);
      const res = await fetch(
        `http://localhost:8000/api/google/events?time_min=${encodeURIComponent(timeMin)}&time_max=${encodeURIComponent(timeMax)}`,
        { credentials: 'include' }
      );
      if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
      const data: CalendarEvent[] = await res.json();
      setEvents(data || []);
    } catch (e) {
      console.error('Failed to fetch Google events', e);
      setEvents([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEvents(currentMonth);
  }, [currentMonth]);

  const refresh = () => loadEvents(currentMonth);

  // Calendar grid helpers -------------------------------------------

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (number | null)[] = [];
    for (let i = 0; i < startingDayOfWeek; i++) days.push(null);
    for (let day = 1; day <= daysInMonth; day++) days.push(day);
    return days;
  };

  const getEventsForDate = (day: number) => {
    const d = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    const key = ymd(d);
    return events.filter((e) => {
      const start = parseEventLocalDate(e.start);
      // Include all-day spans that cover this day
      const end = e.end ? parseEventLocalDate(e.end) : start;
      // For all-day events, Google end is exclusive; adjust by -1 day when length==10
      const correctedEnd =
        e.end && e.end.length === 10 ? new Date(end.getTime() - 24 * 60 * 60 * 1000) : end;

      const dayKey = ymd(d);
      const startKey = ymd(start);
      const endKey = ymd(correctedEnd);
      return dayKey >= startKey && dayKey <= endKey;
    });
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth((prev) => {
      const dt = new Date(prev);
      dt.setMonth(prev.getMonth() + (direction === 'next' ? 1 : -1));
      return dt;
    });
  };

  // UI --------------------------------------------------------------

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Calendar</h1>
          <p className="text-gray-600 mt-1">Your Google Calendar events</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={refresh}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{loading ? 'Refreshing…' : 'Sync Now'}</span>
          </button>

          <button
            onClick={() => setShowAddEvent(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add Event</span>
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-4">
              <button onClick={() => navigateMonth('prev')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <ChevronLeft className="w-5 h-5" />
              </button>

              <h2 className="text-xl font-semibold text-gray-900">
                {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
              </h2>

              <button onClick={() => navigateMonth('next')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setViewType('month')}
                className={`px-3 py-1 text-sm font-medium rounded-lg transition-colors ${viewType === 'month' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-gray-900'
                  }`}
              >
                Month
              </button>
              <button
                onClick={() => setViewType('week')}
                className={`px-3 py-1 text-sm font-medium rounded-lg transition-colors ${viewType === 'week' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-gray-900'
                  }`}
              >
                Week
              </button>
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="p-6">
          <div className="grid grid-cols-7 gap-4 mb-4">
            {weekDays.map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">{day}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-4">
            {getDaysInMonth(currentMonth).map((day, index) => (
              <div key={index}
                className={`min-h-[120px] p-2 border border-gray-200 rounded-lg ${day ? 'bg-white hover:bg-gray-50' : 'bg-gray-50'
                  } transition-colors`}
              >
                {day && (
                  <>
                    <div className="text-sm font-medium text-gray-900 mb-2">{day}</div>
                    <div className="space-y-1">
                      {getEventsForDate(day).map((ev) => {
                        const type = detectType(ev.title);
                        return (
                          <a
                            key={ev.id}
                            className={`block p-1 rounded text-xs text-white font-medium truncate ${eventColors[type]}`}
                            title={ev.title}
                            target="_blank"
                            rel="noreferrer"
                          >
                            {ev.title}
                          </a>
                        );
                      })}

                    </div>
                  </>
                )}
              </div>
            ))}
          </div>

          {loading && <p className="text-sm text-gray-500 mt-4">Loading events…</p>}
        </div>
      </div>

      {showAddEvent && (
        <AddEventModal
          onClose={() => setShowAddEvent(false)}
          onSave={() => setShowAddEvent(false)}
        />
      )}
    </div>
  );
};

export default CalendarView;
