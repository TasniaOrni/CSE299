import React, { useEffect, useMemo, useState } from 'react';
import { User } from '../App';
import {
  Calendar,
  Clock,
  FileText,
  Plus,
  Upload,
  CheckCircle,
  AlertCircle,
  Users,
  BookOpen,
} from 'lucide-react';
import AddEventModal from './AddEventModal';

interface DashboardProps {
  user: User;
}

/** Match your backend response model */
type EventType =
  | 'assignment'
  | 'class'
  | 'exam'
  | 'final'
  | 'project'
  | 'office-hours'
  | 'reminder';

interface EventRead {
  id: string;
  title: string;
  description?: string | null;
  type: EventType;
  event_date: string; // ISO datetime (date part matters)
  task_time: string;  // "HH:MM" or "HH:MM:SS"
  duration_minutes: number;
  is_synced: boolean;
}

const typePill = (type: EventType) => {
  switch (type) {
    case 'assignment':
      return 'bg-blue-100 text-blue-700';
    case 'class':
      return 'bg-yellow-100 text-yellow-700';
    case 'office-hours':
      return 'bg-purple-100 text-purple-700';
    case 'exam':
      return 'bg-red-100 text-red-700';
    case 'final':
      return 'bg-orange-100 text-orange-700';
    case 'project':
      return 'bg-emerald-100 text-emerald-700';
    case 'reminder':
    default:
      return 'bg-gray-100 text-gray-700';
  }
};

const dotColor = (type: EventType) => {
  switch (type) {
    case 'assignment':
      return 'bg-blue-500';
    case 'class':
      return 'bg-yellow-500';
    case 'office-hours':
      return 'bg-purple-500';
    case 'exam':
      return 'bg-red-500';
    case 'final':
      return 'bg-orange-500';
    case 'project':
      return 'bg-emerald-500';
    case 'reminder':
    default:
      return 'bg-gray-400';
  }
};

/** Combine date from event_date with time from task_time into a single JS Date */
function combineEventDateTime(event_date: string, task_time: string): Date {
  // event_date may include time; we trust its date portion.
  const d = new Date(event_date); // assume UTC coming from backend; browser will localize when formatting
  // Parse HH:MM or HH:MM:SS
  const [hh, mm, ss] = task_time.split(':').map((x) => parseInt(x, 10));
  d.setHours(hh || 0, mm || 0, ss || 0, 0);
  return d;
}

function formatDate(dt: Date) {
  return dt.toLocaleDateString(undefined, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
}

function formatTime(dt: Date) {
  return dt.toLocaleTimeString(undefined, {
    hour: 'numeric',
    minute: '2-digit',
  });
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [showAddEvent, setShowAddEvent] = useState(false);

  const [events, setEvents] = useState<EventRead[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  // Fetch from backend
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        setLoading(true);
        const res = await fetch('http://localhost:8000/api/events', {
          credentials: 'include',
        });
        if (!res.ok) {
          throw new Error(`${res.status} ${res.statusText}`);
        }
        const data: EventRead[] = await res.json();
        if (isMounted) {
          setEvents(data ?? []);
          setErr(null);
        }
      } catch (e: any) {
        if (isMounted) setErr(e?.message || 'Failed to load events');
      } finally {
        if (isMounted) setLoading(false);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  // Build enriched items with combined start datetime
  const enriched = useMemo(() => {
    return events.map((ev) => {
      const start = combineEventDateTime(ev.event_date, ev.task_time);
      const end = new Date(start.getTime() + (ev.duration_minutes ?? 60) * 60_000);
      return { ...ev, start, end };
    });
  }, [events]);

  const now = new Date();
  const todayKey = now.toISOString().slice(0, 10); // "YYYY-MM-DD"

  // Upcoming: future events sorted (limit 5–6)
  const upcomingEvents = useMemo(() => {
    return enriched
      .filter((ev) => ev.start >= now)
      .sort((a, b) => a.start.getTime() - b.start.getTime())
      .slice(0, 6);
  }, [enriched]);

  // Today’s schedule: events whose local date == today, sorted by time
  const todaysEvents = useMemo(() => {
    return enriched
      .filter((ev) => {
        // Compare local date parts
        const y = ev.start.getFullYear();
        const m = ev.start.getMonth();
        const d = ev.start.getDate();
        const key = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        return key === todayKey;
      })
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  }, [enriched, todayKey]);

  const renderStudentDashboard = () => (
    <>
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <button
          onClick={() => setShowAddEvent(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white p-6 rounded-xl shadow-sm transition-colors flex items-center gap-3"
        >
          <Plus className="w-6 h-6" />
          <span className="font-medium">Add Assignment</span>
        </button>

        <button className="bg-green-600 hover:bg-green-700 text-white p-6 rounded-xl shadow-sm transition-colors flex items-center gap-3">
          <Upload className="w-6 h-6" />
          <span className="font-medium">Upload Schedule</span>
        </button>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex items-center gap-3">
          <CheckCircle className="w-6 h-6 text-green-500" />
          <div>
            <p className="font-medium text-gray-900">Google Calendar</p>
            <p className="text-sm text-green-600">Synced</p>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upcoming Events */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Upcoming Events
              </h2>
            </div>

            <div className="p-6">
              {loading ? (
                <p className="text-gray-500">Loading…</p>
              ) : err ? (
                <p className="text-red-600">Failed to load events: {err}</p>
              ) : upcomingEvents.length === 0 ? (
                <p className="text-gray-500">No upcoming events.</p>
              ) : (
                <div className="space-y-4">
                  {upcomingEvents.map((event) => (
                    <div
                      key={event.id}
                      className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <div className={`w-3 h-3 rounded-full ${dotColor(event.type)}`} />
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{event.title}</h3>
                        <p className="text-sm text-gray-600">
                          {formatDate(event.start)} at {formatTime(event.start)}
                        </p>
                      </div>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${typePill(event.type)}`}>
                        {event.type}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              Today's Schedule
            </h2>
          </div>
          <div className="p-6">
            {loading ? (
              <p className="text-gray-500">Loading…</p>
            ) : err ? (
              <p className="text-red-600">Failed to load events: {err}</p>
            ) : todaysEvents.length === 0 ? (
              <p className="text-gray-500">Nothing scheduled for today.</p>
            ) : (
              <div className="space-y-4">
                {todaysEvents.map((item) => (
                  <div key={item.id} className="flex items-center gap-3">
                    <div className="text-sm font-medium text-gray-600 w-24">{formatTime(item.start)}</div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{item.title}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );

  const renderFacultyDashboard = () => (
    <>
      {/* (kept as-is) */}
      {/* You can reuse the same data blocks from student dashboard if you want */}
      {/* … existing faculty UI unchanged … */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <Users className="w-8 h-8 text-blue-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">24</p>
              <p className="text-sm text-gray-600">Students</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <Clock className="w-8 h-8 text-green-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">8</p>
              <p className="text-sm text-gray-600">Office Hours/Week</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">3</p>
              <p className="text-sm text-gray-600">Courses</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <FileText className="w-8 h-8 text-orange-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">12</p>
              <p className="text-sm text-gray-600">Pending Reviews</p>
            </div>
          </div>
        </div>
      </div>

      {/* You can also show upcoming/today blocks here if needed, same as student */}
    </>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          Welcome back, {user.name}
        </h1>
        <p className="text-gray-600 mt-2">
          {user.role === 'student'
            ? "Here's your academic overview"
            : user.role === 'faculty'
            ? 'Manage your courses and office hours'
            : 'Assist students and manage resources'}
        </p>
      </div>

      {user.role === 'student' ? renderStudentDashboard() : renderFacultyDashboard()}

      {showAddEvent && (
        <AddEventModal
          onClose={() => setShowAddEvent(false)}
          onSave={(created) => {
            // Optimistic refresh: append the new event to the list
            try {
              const cast: EventRead = created; // your /api/events POST returns EventRead
              setEvents((prev) => [...prev, cast]);
            } catch {
              // ignore if shapes differ
            }
            setShowAddEvent(false);
          }}
        />
      )}
    </div>
  );
};

export default Dashboard;
