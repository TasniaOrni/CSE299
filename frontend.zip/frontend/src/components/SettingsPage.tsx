import React, { useState } from 'react';
import { User } from '../App';
import {
  RefreshCw,
  Upload,
  User as UserIcon,
  Bell,
  Shield,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Download,
} from 'lucide-react';

interface SettingsPageProps {
  user: User;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ user }) => {
  const [twoWaySync, setTwoWaySync] = useState(true);
  const [notifications, setNotifications] = useState({
    assignments: true,
    classes: true,
    officeHours: true,
    reminders: true,
  });
  const [lastSync, setLastSync] = useState('2025-01-14 3:45 PM');

  const handleManualSync = () => {
    setLastSync(new Date().toLocaleString());
    // Simulate sync process
    setTimeout(() => {
      alert('Calendar synchronized successfully!');
    }, 1000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      console.log('Uploading file:', file.name);
      alert(`Schedule file "${file.name}" uploaded successfully!`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-2">Manage your account and sync preferences</p>
      </div>

      <div className="space-y-8">
        {/* Google Calendar Sync */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Google Calendar Integration
            </h2>
          </div>
          <div className="p-6 space-y-6">
            {/* Sync Status */}
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <div>
                  <p className="font-medium text-green-900">Connected to Google Calendar</p>
                  <p className="text-sm text-green-700">Last synced: {lastSync}</p>
                </div>
              </div>
              <button
                onClick={handleManualSync}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                Sync Now
              </button>
            </div>

            {/* Two-Way Sync Toggle */}
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-900">Enable Two-Way Sync</h3>
                <p className="text-sm text-gray-600">
                  Changes in Google Calendar will be reflected in NSU Portal and vice versa
                </p>
              </div>
              <button
                onClick={() => setTwoWaySync(!twoWaySync)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  twoWaySync ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    twoWaySync ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Sync Warning */}
            {twoWaySync && (
              <div className="flex items-start gap-3 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-900">Two-Way Sync Enabled</p>
                  <p className="text-sm text-yellow-700">
                    Events created or modified in Google Calendar will automatically appear in your NSU Portal.
                    Make sure you're using the correct Google account.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Schedule Upload */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <Upload className="w-5 h-5 text-blue-600" />
              Schedule Management
            </h2>
          </div>
          <div className="p-6 space-y-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Upload New Schedule</h3>
              <p className="text-sm text-gray-600 mb-4">
                Upload your class schedule in CSV or Excel format. This will replace your current schedule.
              </p>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium cursor-pointer transition-colors">
                  <Upload className="w-4 h-4" />
                  Choose File
                  <input
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                <span className="text-sm text-gray-500">
                  Supported formats: CSV, XLSX, XLS
                </span>
              </div>
            </div>

            <div>
              <h3 className="font-medium text-gray-900 mb-2">Download Current Schedule</h3>
              <p className="text-sm text-gray-600 mb-4">
                Export your current schedule data as a CSV file.
              </p>
              <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors">
                <Download className="w-4 h-4" />
                Download CSV
              </button>
            </div>
          </div>
        </div>

        {/* Notification Preferences */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-600" />
              Notification Preferences
            </h2>
          </div>
          <div className="p-6 space-y-4">
            {Object.entries(notifications).map(([key, enabled]) => (
              <div key={key} className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-gray-900 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Receive notifications for {key.toLowerCase()} updates
                  </p>
                </div>
                <button
                  onClick={() =>
                    setNotifications(prev => ({ ...prev, [key]: !enabled }))
                  }
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    enabled ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Profile Management */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <UserIcon className="w-5 h-5 text-blue-600" />
              Profile Information
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={user.name}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={user.email}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Role
                </label>
                <input
                  type="text"
                  value={user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Student/Employee ID
                </label>
                <input
                  type="text"
                  value={user.id}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                />
              </div>
            </div>
            <div className="pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-600">
                <Shield className="w-4 h-4 inline mr-1" />
                Profile information is managed by NSU IT Department. 
                Contact support for changes.
              </p>
            </div>
          </div>
        </div>

        {/* Advanced Settings */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Advanced Settings</h2>
          </div>
          <div className="p-6 space-y-4">
            <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
              <h3 className="font-medium text-gray-900">Clear Calendar Cache</h3>
              <p className="text-sm text-gray-600">Remove all cached calendar data and force a fresh sync</p>
            </button>
            <button className="w-full text-left p-4 border border-red-200 rounded-lg hover:bg-red-50 transition-colors">
              <h3 className="font-medium text-red-900">Disconnect Google Calendar</h3>
              <p className="text-sm text-red-600">Remove the connection to your Google Calendar account</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;